"""
Package for DjangoToAndroid.
"""
